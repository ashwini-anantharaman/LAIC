
  # Follow Markdown Prompt

  This is a code bundle for Follow Markdown Prompt. The original project is available at https://www.figma.com/design/Escgvb5qbzQzjfxXrdc2N7/Follow-Markdown-Prompt.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  