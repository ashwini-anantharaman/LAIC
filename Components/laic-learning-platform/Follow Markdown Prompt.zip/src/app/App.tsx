import { useState, useEffect, useRef } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Send, ChevronLeft, ChevronRight, Check } from "lucide-react";

// ── Asset imports ──────────────────────────────────────────────────────────────
import frame1 from "../imports/frame-1-owl.png";
import frame2 from "../imports/frame-2-owl.png";
import frame3 from "../imports/frame-3-owl.png";
import rubinVase from "../imports/InteractiveMode-1/97b20c55a0746afbe29344ee6e519a924f9a40c8.png";
import owlAvatar from "../imports/InteractiveMode-1/2da62d230eab2fcaa09dc117f216257b17160f6a.png";

// ── Owl animation ─────────────────────────────────────────────────────────────
const OWL_FRAMES = [frame1, frame2, frame3];

function OwlAnim({ className = "" }: { className?: string }) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setIdx(i => (i + 1) % 3), 130);
    return () => clearInterval(id);
  }, []);
  return (
    <img
      src={OWL_FRAMES[idx]}
      alt="Owlwise"
      className={className}
      style={{ imageRendering: "auto" }}
    />
  );
}

// ── Types ─────────────────────────────────────────────────────────────────────
type Screen =
  | "splash" | "login"
  | "ob1" | "ob2" | "ob3"
  | "courses" | "unit";

type Mode = "interactive" | "summary" | "narrative";

// ── Shared: mobile shell ──────────────────────────────────────────────────────
function Shell({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className={`relative w-full max-w-[390px] min-h-screen overflow-hidden ${className}`}
        style={{ minHeight: "100svh" }}>
        {children}
      </div>
    </div>
  );
}

// ── Shared: status bar ────────────────────────────────────────────────────────
function StatusBar({ light = false }: { light?: boolean }) {
  const c = light ? "text-white" : "text-black";
  return (
    <div className={`flex justify-between items-center px-6 pt-3 pb-1 text-[13px] font-semibold ${c}`}>
      <span>9:41</span>
      <div className="flex items-center gap-1.5">
        {/* Signal */}
        <svg width="17" height="12" viewBox="0 0 17 12" fill="none">
          <rect x="0" y="7" width="3" height="5" rx="0.5" fill="currentColor" opacity="0.4" />
          <rect x="4.5" y="4.5" width="3" height="7.5" rx="0.5" fill="currentColor" opacity="0.6" />
          <rect x="9" y="2" width="3" height="10" rx="0.5" fill="currentColor" opacity="0.8" />
          <rect x="13.5" y="0" width="3" height="12" rx="0.5" fill="currentColor" />
        </svg>
        {/* Wifi */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <path d="M8 9.5C8.83 9.5 9.5 10.17 9.5 11S8.83 12.5 8 12.5 6.5 11.83 6.5 11 7.17 9.5 8 9.5z" fill="currentColor" />
          <path d="M3.5 6.5C4.9 5.1 6.85 4.2 8 4.2s3.1.9 4.5 2.3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none" />
          <path d="M1 3.5C2.9 1.6 5.3.5 8 .5s5.1 1.1 7 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none" opacity="0.5" />
        </svg>
        {/* Battery */}
        <svg width="25" height="12" viewBox="0 0 25 12" fill="none">
          <rect x="0.5" y="0.5" width="21" height="11" rx="3" stroke="currentColor" strokeOpacity="0.35" />
          <rect x="2" y="2" width="18" height="8" rx="1.5" fill="currentColor" />
          <path d="M22.5 4v4c.83-.37 1.33-1.17 1.33-2S23.33 4.37 22.5 4z" fill="currentColor" opacity="0.4" />
        </svg>
      </div>
    </div>
  );
}

// ── Shared: step dots ─────────────────────────────────────────────────────────
function StepDots({ total, current }: { total: number; current: number }) {
  return (
    <div className="flex gap-1.5 justify-center">
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} className={`rounded-full transition-all duration-300 ${i === current ? "w-5 h-1.5 bg-[#602424]" : "w-1.5 h-1.5 bg-gray-300"}`} />
      ))}
    </div>
  );
}

// ── Shared: slide transition ──────────────────────────────────────────────────
function Slide({ children, dir = 1 }: { children: React.ReactNode; dir?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: dir * 28 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: dir * -28 }}
      transition={{ duration: 0.28, ease: [0.32, 0, 0.18, 1] }}
      className="size-full"
    >
      {children}
    </motion.div>
  );
}

// ── Screen: Splash ────────────────────────────────────────────────────────────
function Splash({ nav }: { nav: (s: Screen) => void }) {
  return (
    <Shell className="bg-[#fdf8f5]">
      <div className="flex flex-col items-center justify-center min-h-screen px-8 gap-0">
        <div className="flex flex-col items-center gap-6 mb-16">
          <OwlAnim className="w-32 h-32 object-contain" />
          <div className="text-center">
            <h1 className="text-[34px] font-bold text-[#2c0312] tracking-tight leading-none">Owlwise</h1>
            <p className="text-[15px] text-gray-500 mt-2 font-normal">Learn at your pace, your way.</p>
          </div>
        </div>
        <div className="w-full flex flex-col gap-3">
          <button
            onClick={() => nav("login")}
            className="w-full py-4 rounded-2xl bg-[#602424] text-white text-[16px] font-semibold tracking-tight active:scale-[0.98] transition-transform"
          >
            Get started
          </button>
          <button
            onClick={() => nav("login")}
            className="w-full py-4 rounded-2xl border border-gray-200 bg-white text-[#602424] text-[16px] font-semibold tracking-tight active:scale-[0.98] transition-transform"
          >
            Sign in
          </button>
        </div>
        <p className="text-[12px] text-gray-400 mt-6 text-center leading-relaxed">
          By continuing you agree to our Terms of Service and Privacy Policy.
        </p>
      </div>
    </Shell>
  );
}

// ── Screen: Login ─────────────────────────────────────────────────────────────
function Login({ nav }: { nav: (s: Screen) => void }) {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  return (
    <Shell className="bg-[#fdf8f5]">
      <StatusBar />
      <div className="flex flex-col min-h-[calc(100svh-44px)] px-6 pt-4">
        <button onClick={() => nav("splash")} className="w-8 h-8 flex items-center justify-center -ml-1 mb-6">
          <ChevronLeft size={22} className="text-gray-600" />
        </button>
        <div className="flex flex-col items-start gap-1 mb-8">
          <OwlAnim className="w-14 h-14 object-contain mb-3" />
          <h2 className="text-[28px] font-bold text-[#2c0312] tracking-tight leading-tight">Welcome back</h2>
          <p className="text-[14px] text-gray-500">Sign in to continue learning</p>
        </div>
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-[13px] font-medium text-gray-700">Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@school.edu"
              className="w-full px-4 py-3.5 rounded-xl border border-gray-200 bg-white text-[15px] outline-none focus:border-[#602424] focus:ring-2 focus:ring-[#602424]/10 transition-all"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-[13px] font-medium text-gray-700">Password</label>
            <input
              type="password"
              value={pass}
              onChange={e => setPass(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-3.5 rounded-xl border border-gray-200 bg-white text-[15px] outline-none focus:border-[#602424] focus:ring-2 focus:ring-[#602424]/10 transition-all"
            />
          </div>
          <button
            onClick={() => nav("ob1")}
            className="w-full py-4 rounded-2xl bg-[#602424] text-white text-[16px] font-semibold mt-2 active:scale-[0.98] transition-transform"
          >
            Continue
          </button>
          <p className="text-center text-[14px] text-gray-500">
            New here?{" "}
            <span className="text-[#602424] font-medium" onClick={() => nav("ob1")}>Create account</span>
          </p>
        </div>
      </div>
    </Shell>
  );
}

// ── Onboarding shell ─────────────────────────────────────────────────────────
function ObShell({ step, total, onBack, onNext, nextLabel = "Continue", nextDisabled = false, children }: {
  step: number; total: number;
  onBack: () => void; onNext: () => void;
  nextLabel?: string; nextDisabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <Shell className="bg-[#fdf8f5]">
      <StatusBar />
      <div className="flex flex-col min-h-[calc(100svh-44px)] px-6 pt-4 pb-8">
        <div className="flex items-center justify-between mb-6">
          <button onClick={onBack} className="w-8 h-8 flex items-center justify-center -ml-1">
            <ChevronLeft size={22} className="text-gray-600" />
          </button>
          <StepDots total={total} current={step} />
          <div className="w-8" />
        </div>
        <div className="flex-1">{children}</div>
        <button
          onClick={onNext}
          disabled={nextDisabled}
          className={`w-full py-4 rounded-2xl text-[16px] font-semibold transition-all active:scale-[0.98] ${nextDisabled ? "bg-gray-200 text-gray-400" : "bg-[#602424] text-white"}`}
        >
          {nextLabel}
        </button>
      </div>
    </Shell>
  );
}

// ── Screen: Onboard 1 — Age & grade ──────────────────────────────────────────
function Ob1({ nav }: { nav: (s: Screen) => void }) {
  const [grade, setGrade] = useState("");
  const grades = ["6th", "7th", "8th", "9th", "10th", "11th", "12th", "College"];
  return (
    <ObShell step={0} total={3} onBack={() => nav("login")} onNext={() => nav("ob2")} nextDisabled={!grade}>
      <h2 className="text-[26px] font-bold text-[#2c0312] tracking-tight mb-1">What grade are you in?</h2>
      <p className="text-[14px] text-gray-500 mb-8">We use this to set the right reading level and content depth.</p>
      <div className="grid grid-cols-4 gap-2.5">
        {grades.map(g => (
          <button
            key={g}
            onClick={() => setGrade(g)}
            className={`py-3.5 rounded-xl text-[14px] font-medium border transition-all active:scale-95 ${grade === g ? "bg-[#602424] text-white border-[#602424]" : "bg-white text-gray-700 border-gray-200"}`}
          >
            {g}
          </button>
        ))}
      </div>
    </ObShell>
  );
}

// ── Screen: Onboard 2 — Visual style ─────────────────────────────────────────
const VISUAL_OPTIONS = [
  {
    id: "newspaper",
    label: "Newspaper",
    desc: "Dense, article-style layout with rich typography",
    preview: (
      <div className="w-full h-full bg-[#ffeec3] rounded-lg p-2.5 flex flex-col gap-1.5">
        <div className="h-3 w-20 bg-[#2c0312] rounded-sm" />
        <div className="h-1.5 w-full bg-[#2c0312]/20 rounded-sm" />
        <div className="h-1.5 w-4/5 bg-[#2c0312]/20 rounded-sm" />
        <div className="h-1.5 w-full bg-[#2c0312]/20 rounded-sm" />
        <div className="h-10 bg-[#2c0312]/15 rounded mt-1" />
        <div className="h-1.5 w-3/4 bg-[#2c0312]/20 rounded-sm" />
      </div>
    ),
  },
  {
    id: "interactive",
    label: "Chat",
    desc: "Conversational, message-based learning",
    preview: (
      <div className="w-full h-full bg-[#161618] rounded-lg p-2.5 flex flex-col gap-2">
        <div className="bg-[#4a5273]/40 rounded-xl rounded-tl-sm p-2">
          <div className="h-1.5 w-full bg-white/30 rounded-sm mb-1" />
          <div className="h-1.5 w-3/4 bg-white/30 rounded-sm" />
        </div>
        <div className="bg-[#4a5273]/40 rounded-xl rounded-tl-sm p-2 self-end w-4/5">
          <div className="h-1.5 w-full bg-white/30 rounded-sm" />
        </div>
        <div className="mt-auto h-4 bg-[#4a5273]/40 rounded-full" />
      </div>
    ),
  },
];

function Ob2({ nav }: { nav: (s: Screen) => void }) {
  const [sel, setSel] = useState("");
  return (
    <ObShell step={1} total={3} onBack={() => nav("ob1")} onNext={() => nav("ob3")} nextDisabled={!sel}>
      <h2 className="text-[26px] font-bold text-[#2c0312] tracking-tight mb-1">How do you like to read?</h2>
      <p className="text-[14px] text-gray-500 mb-8">This sets your default reading layout. You can switch any time.</p>
      <div className="flex flex-col gap-3">
        {VISUAL_OPTIONS.map(o => (
          <button
            key={o.id}
            onClick={() => setSel(o.id)}
            className={`flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all active:scale-[0.98] ${sel === o.id ? "border-[#602424]" : "border-gray-200 bg-white"}`}
          >
            <div className="w-20 h-16 rounded-lg overflow-hidden shrink-0">{o.preview}</div>
            <div className="flex-1">
              <p className="font-semibold text-[15px] text-gray-900">{o.label}</p>
              <p className="text-[12px] text-gray-500 mt-0.5 leading-snug">{o.desc}</p>
            </div>
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${sel === o.id ? "bg-[#602424] border-[#602424]" : "border-gray-300"}`}>
              {sel === o.id && <Check size={11} className="text-white" strokeWidth={3} />}
            </div>
          </button>
        ))}
      </div>
    </ObShell>
  );
}

// ── Screen: Onboard 3 — Learning style ───────────────────────────────────────
const STYLE_OPTIONS = [
  { id: "interactive", label: "Interactive", desc: "Message-by-message, like a conversation with a tutor" },
  { id: "summary", label: "Summary", desc: "Concise newspaper-style articles covering the key ideas" },
  { id: "narrative", label: "Narrative", desc: "Story-driven content that brings concepts to life" },
  { id: "instructor", label: "As your teacher designed it", desc: "Exactly how your instructor put it together" },
];

function Ob3({ nav }: { nav: (s: Screen) => void }) {
  const [sel, setSel] = useState("");
  return (
    <ObShell step={2} total={3} onBack={() => nav("ob2")} onNext={() => nav("courses")} nextLabel="Start learning" nextDisabled={!sel}>
      <h2 className="text-[26px] font-bold text-[#2c0312] tracking-tight mb-1">How do you learn best?</h2>
      <p className="text-[14px] text-gray-500 mb-8">You can always switch formats mid-lesson.</p>
      <div className="flex flex-col gap-2.5">
        {STYLE_OPTIONS.map(o => (
          <button
            key={o.id}
            onClick={() => setSel(o.id)}
            className={`flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all active:scale-[0.98] ${sel === o.id ? "border-[#602424]" : "border-gray-200 bg-white"}`}
          >
            <div className="flex-1">
              <p className="font-semibold text-[15px] text-gray-900">{o.label}</p>
              <p className="text-[12px] text-gray-500 mt-0.5 leading-snug">{o.desc}</p>
            </div>
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${sel === o.id ? "bg-[#602424] border-[#602424]" : "border-gray-300"}`}>
              {sel === o.id && <Check size={11} className="text-white" strokeWidth={3} />}
            </div>
          </button>
        ))}
      </div>
    </ObShell>
  );
}

// ── Screen: Courses home ──────────────────────────────────────────────────────
const COURSES = [
  { id: 1, name: "AP Biology", unit: "Perception & the Nervous System", teacher: "Ms. Johnson", units: 4, progress: 38 },
  { id: 2, name: "World History", unit: "Industrial Revolution", teacher: "Mr. Davis", units: 6, progress: 0 },
];

function Courses({ nav }: { nav: (s: Screen) => void }) {
  const [joining, setJoining] = useState(false);
  const [code, setCode] = useState("");

  return (
    <Shell className="bg-[#fdf8f5]">
      <StatusBar />
      <div className="px-6 pt-2 pb-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <p className="text-[13px] text-gray-500 font-medium">Good morning,</p>
            <h2 className="text-[26px] font-bold text-[#2c0312] tracking-tight leading-tight">My courses</h2>
          </div>
          <OwlAnim className="w-12 h-12 object-contain" />
        </div>

        {/* Join button */}
        <button
          onClick={() => setJoining(true)}
          className="w-full mb-5 py-3.5 rounded-2xl border-2 border-dashed border-gray-300 text-gray-500 text-[14px] font-medium flex items-center justify-center gap-2 hover:border-[#602424] hover:text-[#602424] transition-all active:scale-[0.98]"
        >
          <span className="text-[20px] leading-none font-light">+</span> Join a course
        </button>

        {/* Course cards */}
        <div className="flex flex-col gap-3">
          {COURSES.map(c => (
            <button
              key={c.id}
              onClick={() => nav("unit")}
              className="w-full bg-white rounded-2xl border border-gray-100 p-5 text-left flex flex-col gap-3 active:scale-[0.98] transition-transform shadow-sm"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[11px] font-semibold text-[#602424] uppercase tracking-widest">{c.name}</p>
                  <p className="text-[16px] font-semibold text-gray-900 mt-0.5 leading-snug">{c.unit}</p>
                  <p className="text-[12px] text-gray-400 mt-1">{c.teacher} · {c.units} units</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-[#f5ede8] flex items-center justify-center shrink-0">
                  <ChevronRight size={16} className="text-[#602424]" />
                </div>
              </div>
              {c.progress > 0 && (
                <div>
                  <div className="flex justify-between text-[11px] text-gray-400 mb-1.5">
                    <span>Progress</span><span>{c.progress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${c.progress}%` }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      className="h-full bg-[#602424] rounded-full"
                    />
                  </div>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Join modal */}
      <AnimatePresence>
        {joining && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/40 flex items-end z-50"
            onClick={() => setJoining(false)}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ duration: 0.28, ease: [0.32, 0, 0.18, 1] }}
              onClick={e => e.stopPropagation()}
              className="w-full bg-[#fdf8f5] rounded-t-3xl p-6 pb-10"
            >
              <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-6" />
              <h3 className="text-[20px] font-bold text-[#2c0312] mb-5">Join a course</h3>
              <div className="flex flex-col gap-3">
                <button className="w-full py-4 rounded-2xl border-2 border-gray-200 bg-white text-[15px] font-medium text-gray-700 active:scale-[0.98] transition-transform">
                  Join with link
                </button>
                <div className="flex flex-col gap-2">
                  <input
                    value={code}
                    onChange={e => setCode(e.target.value.toUpperCase())}
                    placeholder="Classroom code"
                    className="w-full py-4 px-4 rounded-2xl border-2 border-gray-200 bg-white text-[18px] font-bold text-center tracking-widest text-gray-800 outline-none focus:border-[#602424] transition-all"
                  />
                  <button
                    onClick={() => { setJoining(false); nav("unit"); }}
                    className="w-full py-4 rounded-2xl bg-[#602424] text-white text-[16px] font-semibold active:scale-[0.98] transition-transform"
                  >
                    Join
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Shell>
  );
}

// ── Mode toggle icons ─────────────────────────────────────────────────────────
function IconInteractive({ active }: { active: boolean }) {
  // Owl face
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <ellipse cx="11" cy="12" rx="8" ry="7" fill={active ? "white" : "white"} fillOpacity={active ? 1 : 0.4} />
      <ellipse cx="8" cy="12.5" rx="2.5" ry="2.5" fill={active ? "#161618" : "#555"} />
      <ellipse cx="14" cy="12.5" rx="2.5" ry="2.5" fill={active ? "#161618" : "#555"} />
      <path d="M9 9.5c0-1.1.9-2 2-2s2 .9 2 2" stroke={active ? "#161618" : "#555"} strokeWidth="1.2" fill="none" />
      <circle cx="8.5" cy="12" r="0.8" fill={active ? "white" : "white"} />
      <circle cx="14.5" cy="12" r="0.8" fill={active ? "white" : "white"} />
    </svg>
  );
}

function IconSummary({ active, dark = false }: { active: boolean; dark?: boolean }) {
  const c = dark ? (active ? "#2c0312" : "#2c0312") : (active ? "white" : "white");
  const op = active ? 1 : 0.4;
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <rect x="3" y="2" width="14" height="16" rx="2" stroke={c} strokeOpacity={op} strokeWidth="1.5" fill="none" />
      <line x1="6" y1="6" x2="14" y2="6" stroke={c} strokeOpacity={op} strokeWidth="1.2" strokeLinecap="round" />
      <line x1="6" y1="9" x2="14" y2="9" stroke={c} strokeOpacity={op} strokeWidth="1.2" strokeLinecap="round" />
      <line x1="6" y1="12" x2="11" y2="12" stroke={c} strokeOpacity={op} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function IconNarrative({ active, dark = false }: { active: boolean; dark?: boolean }) {
  const c = dark ? (active ? "#2c0312" : "#2c0312") : (active ? "white" : "white");
  const op = active ? 1 : 0.4;
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <circle cx="10" cy="10" r="7.5" stroke={c} strokeOpacity={op} strokeWidth="1.5" fill="none" />
      <ellipse cx="10" cy="10" rx="3" ry="7.5" stroke={c} strokeOpacity={op} strokeWidth="1" fill="none" />
      <line x1="2.5" y1="10" x2="17.5" y2="10" stroke={c} strokeOpacity={op} strokeWidth="1" />
      <line x1="3.5" y1="7" x2="16.5" y2="7" stroke={c} strokeOpacity={op} strokeWidth="0.8" />
      <line x1="3.5" y1="13" x2="16.5" y2="13" stroke={c} strokeOpacity={op} strokeWidth="0.8" />
    </svg>
  );
}

// ── Unit: top bar shared ──────────────────────────────────────────────────────
function UnitTopBar({
  mode, setMode, light = false, progressColor = "bg-green-300"
}: {
  mode: Mode; setMode: (m: Mode) => void; light?: boolean; progressColor?: string;
}) {
  return (
    <div>
      {/* Module label + progress bar row */}
      <div className="flex items-center gap-3 px-5 pt-2 pb-3">
        <span className={`text-[32px] font-bold leading-tight tracking-tight ${light ? "text-white" : "text-[#2c0312]"}`}>
          Module 1
        </span>
        <div className="flex-1 h-[22px] rounded-full overflow-hidden" style={{ background: light ? "rgba(74,82,115,0.3)" : "rgba(91,69,77,0.25)" }}>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: "38%" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className={`h-full rounded-full ${progressColor}`}
          />
        </div>
      </div>
      {/* Mode switcher row */}
      <div className="flex justify-end px-5 pb-2">
        <div className="flex items-center gap-1">
          {(["interactive", "summary", "narrative"] as Mode[]).map(m => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`w-9 h-8 rounded-xl flex items-center justify-center transition-all ${mode === m ? (light ? "bg-white/20" : "bg-black/10") : ""}`}
            >
              {m === "interactive" && <IconInteractive active={mode === m} />}
              {m === "summary" && <IconSummary active={mode === m} dark={!light} />}
              {m === "narrative" && <IconNarrative active={mode === m} dark={!light} />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Unit: Interactive mode ────────────────────────────────────────────────────
function InteractiveView({ nav }: { nav: (s: Screen) => void; mode: Mode; setMode: (m: Mode) => void }) {
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState<{ from: "ai" | "user"; text: string }[]>([]);
  const [chatOpen, setChatOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const send = () => {
    const t = chatInput.trim();
    if (!t) return;
    setMessages(m => [...m, { from: "user", text: t }, { from: "ai", text: "Perception is your brain constructing meaning from raw sensory data. Think of it this way: two people can look at the same thing and see something completely different — your prior experiences shape what you perceive." }]);
    setChatInput("");
  };

  return (
    <div className="flex flex-col h-full">
      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto px-3 pb-4">
        {/* Subtitle */}
        <p className="text-white text-[22px] font-normal px-2 pb-4 leading-snug">What is Perception?</p>

        {/* Bubble 1 */}
        <div className="mb-4">
          <div className="bg-[#4a5273]/20 rounded-2xl rounded-tl-sm mx-1 p-4">
            <p className="text-white text-[16px] leading-relaxed">
              {"Let's talk about perception!"}
            </p>
            <p className="text-white text-[16px] leading-relaxed mt-3">
              <span className="font-semibold">Perception</span>
              {" is your brain taking in stuff from your senses, like what you see, hear, and smell, and figuring out what it means."}
            </p>
          </div>
        </div>

        {/* Bubble 2 */}
        <div className="mb-4">
          <div className="bg-[#4a5273]/20 rounded-2xl rounded-tl-sm mx-1 overflow-hidden">
            <div className="p-0">
              <img src={rubinVase} alt="Rubin Vase optical illusion" className="w-full object-cover" style={{ maxHeight: 200 }} />
            </div>
            <div className="p-4">
              <p className="text-white text-[15px] leading-relaxed">
                For example, you might see this Rubin Vase as two faces, or a goblet.
              </p>
            </div>
          </div>
        </div>

        {/* AI chat messages */}
        {messages.length > 0 && (
          <div className="flex flex-col gap-3 px-1 mt-2">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"} gap-2`}>
                {m.from === "ai" && (
                  <div className="w-7 h-7 rounded-full overflow-hidden shrink-0 self-end">
                    <img src={owlAvatar} alt="" className="w-full h-full object-cover scale-150" />
                  </div>
                )}
                <div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-[14px] leading-relaxed ${m.from === "user" ? "bg-[#602424] text-white rounded-br-sm" : "bg-[#4a5273]/20 text-white rounded-bl-sm"}`}>
                  {m.text}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Continue + chat bar */}
      <div className="px-4 pb-2">
        <div className="flex justify-end mb-2">
          <button
            onClick={() => nav("courses")}
            className="px-6 py-2 bg-[#b2f99b] text-[#0a2e0a] text-[14px] font-semibold rounded-full shadow-sm active:scale-[0.97] transition-transform"
          >
            Continue
          </button>
        </div>
        <div className="flex items-center gap-2 bg-[#4a5273]/20 rounded-full px-4 py-2.5">
          <div className="w-8 h-8 rounded-full overflow-hidden shrink-0">
            <img src={owlAvatar} alt="" className="w-full h-full object-cover scale-150" />
          </div>
          <input
            ref={inputRef}
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            onFocus={() => setChatOpen(true)}
            placeholder="Ask me any questions..."
            className="flex-1 bg-transparent text-[#9a9a9a] text-[16px] outline-none placeholder:text-[#9a9a9a]"
          />
          {chatInput.trim() && (
            <button onClick={send} className="shrink-0">
              <Send size={16} className="text-white/60" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Unit: Summary mode ────────────────────────────────────────────────────────
function SummaryView({ nav }: { nav: (s: Screen) => void }) {
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState<{ from: "ai" | "user"; text: string }[]>([]);

  const send = () => {
    const t = chatInput.trim();
    if (!t) return;
    setMessages(m => [...m, { from: "user", text: t }, { from: "ai", text: "The key insight is that perception is an active process — your brain constructs a model of reality rather than simply receiving it. Context, expectations, and experience all shape what you ultimately perceive." }]);
    setChatInput("");
  };

  return (
    <div className="flex flex-col h-full" style={{ fontFamily: "'PT Serif', Georgia, serif" }}>
      <div className="flex-1 overflow-y-auto px-5 pb-4">
        {/* Title */}
        <h2 className="text-[28px] font-bold text-[#2c0312] mb-4 leading-tight" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          Perception
        </h2>

        {/* Body */}
        <div className="text-[15px] text-[#2c0312] leading-[1.75]">
          <p>
            {"The word perception comes from the Latin word "}
            <em>perceptio</em>
            {", meaning “gathering” or “receiving.”"}
          </p>
          <p className="mt-4">
            Perception is the process by which your brain identifies, interprets, and organizes information from your senses. Your sense organs, like your eyes, ears, and nose, take in information from the world around you, and your brain sorts through it and makes sense of it. This is what allows you to understand and form a picture of your environment.
          </p>
        </div>

        {/* Image */}
        <div className="mt-5 border-[3px] border-[#3b202a] rounded-sm overflow-hidden">
          <img src={rubinVase} alt="Rubin Vase" className="w-full object-cover" />
        </div>
        <p className="mt-1.5 text-[11px] italic text-[#602424]" style={{ fontFamily: "'PT Serif', Georgia, serif" }}>
          Fig 1. The Rubin Vase can be perceived as two faces, or a goblet.
        </p>

        {/* AI messages */}
        {messages.length > 0 && (
          <div className="flex flex-col gap-3 mt-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"} gap-2`}>
                {m.from === "ai" && (
                  <OwlAnim className="w-7 h-7 object-contain shrink-0 self-end" />
                )}
                <div className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-[14px] leading-relaxed ${m.from === "user" ? "bg-[#3b202a] text-white" : "bg-[#5a454d]/20 text-[#2c0312]"}`}
                  style={{ fontFamily: "inherit" }}>
                  {m.text}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Continue + chat */}
      <div className="px-5 pb-2">
        <div className="flex justify-end mb-2">
          <button
            onClick={() => nav("courses")}
            className="px-7 py-3 bg-[#3b202a] text-white text-[16px] font-bold rounded-2xl active:scale-[0.97] transition-transform"
            style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
          >
            Continue
          </button>
        </div>
        <div className="flex items-center gap-2 bg-[#5a454d] rounded-full px-4 py-3">
          <OwlAnim className="w-6 h-6 object-contain shrink-0" />
          <input
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            placeholder="Ask a question..."
            className="flex-1 bg-transparent text-[#9a9a9a] text-[15px] outline-none placeholder:text-[#9a9a9a]"
            style={{ fontFamily: "'PT Serif', Georgia, serif" }}
          />
          {chatInput.trim() && (
            <button onClick={send}><Send size={15} className="text-white/50" /></button>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Unit: Narrative mode ──────────────────────────────────────────────────────
function NarrativeView({ nav }: { nav: (s: Screen) => void }) {
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState<{ from: "ai" | "user"; text: string }[]>([]);

  const send = () => {
    const t = chatInput.trim();
    if (!t) return;
    setMessages(m => [...m, { from: "user", text: t }, { from: "ai", text: "Your brain doesn't simply record reality. It actively builds a model — filling gaps, making predictions, and drawing on memory. That's why two people can witness the same event and remember it differently." }]);
    setChatInput("");
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto px-5 pb-4">
        {/* Title */}
        <h2 className="text-[26px] font-bold text-black mb-4 leading-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Perception
        </h2>

        {/* Story body */}
        <div className="text-[12.5px] text-black leading-[1.8]" style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
          <p className="font-bold text-[14px] mb-2">Imagine walking into a kitchen...</p>
          <p className="mb-3">
            And instantly smelling something amazing. Before you even think about it, your brain already knows: cookies. It catches the smell, hears the clink of a baking sheet, feels the warmth in the air, and pieces it all together in an instant.
          </p>
          <p className="mb-3">
            {"That's "}
            <strong>perception</strong>
            {". It comes from the Latin word "}
            <em>perceptio</em>
            {", meaning “gathering” or “receiving.”"}
          </p>
          <p className="mb-4">
            Your brain is taking the world as raw inputs, and turning it into something real, like recognizing a friend's face.
          </p>
        </div>

        {/* Image + caption side by side */}
        <div className="flex gap-3 mb-4">
          <div className="w-[48%] shrink-0 overflow-hidden rounded-sm">
            <img src={rubinVase} alt="Rubin Vase" className="w-full h-full object-cover" />
          </div>
          <p className="text-[11.5px] text-black leading-[1.7]" style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
            {"Here's an optical illusion that shows how perception can differ between individuals: Do you see two faces or a vase?"}
          </p>
        </div>

        {/* AI messages */}
        {messages.length > 0 && (
          <div className="flex flex-col gap-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"} gap-2`}>
                {m.from === "ai" && (
                  <OwlAnim className="w-7 h-7 object-contain shrink-0 self-end" />
                )}
                <div
                  className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-[12px] leading-relaxed ${m.from === "user" ? "bg-[#535353] text-white" : "bg-[#535353]/15 text-black"}`}
                  style={{ fontFamily: "'IBM Plex Mono', monospace" }}
                >
                  {m.text}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Continue + chat */}
      <div className="px-5 pb-2">
        <div className="flex justify-end mb-2">
          <button
            onClick={() => nav("courses")}
            className="px-7 py-3 bg-black text-white text-[15px] font-medium rounded-2xl active:scale-[0.97] transition-transform"
            style={{ fontFamily: "'IBM Plex Mono', monospace" }}
          >
            Continue
          </button>
        </div>
        <div className="flex items-center gap-2 bg-[#535353] rounded-full px-4 py-3">
          <OwlAnim className="w-6 h-6 object-contain shrink-0" />
          <input
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            placeholder="Ask a question..."
            className="flex-1 bg-transparent text-[#9a9a9a] text-[15px] outline-none placeholder:text-[#9a9a9a]"
            style={{ fontFamily: "'IBM Plex Mono', monospace" }}
          />
          {chatInput.trim() && (
            <button onClick={send}><Send size={15} className="text-white/50" /></button>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Screen: Unit (lesson view) ────────────────────────────────────────────────
function Unit({ nav }: { nav: (s: Screen) => void }) {
  const [mode, setMode] = useState<Mode>("interactive");

  const configs: Record<Mode, { bg: string; statusLight: boolean; progressColor: string }> = {
    interactive: { bg: "#161618", statusLight: true, progressColor: "bg-gradient-to-r from-[#d2f1c7] to-[#a8fd8c]" },
    summary: { bg: "#ffeec3", statusLight: false, progressColor: "bg-[#5a454d]" },
    narrative: { bg: "#fcf5e3", statusLight: false, progressColor: "bg-[#535353]" },
  };

  const cfg = configs[mode];

  return (
    <Shell className="overflow-hidden" style={{ background: cfg.bg } as React.CSSProperties}>
      <div
        className="flex flex-col h-screen"
        style={{ background: cfg.bg, minHeight: "100svh" }}
      >
        <StatusBar light={cfg.statusLight} />
        <UnitTopBar
          mode={mode}
          setMode={m => setMode(m)}
          light={cfg.statusLight}
          progressColor={cfg.progressColor}
        />

        {/* Mode content */}
        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            {mode === "interactive" && (
              <motion.div
                key="interactive"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="absolute inset-0 flex flex-col"
              >
                <InteractiveView nav={nav} mode={mode} setMode={setMode} />
              </motion.div>
            )}
            {mode === "summary" && (
              <motion.div
                key="summary"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="absolute inset-0 flex flex-col"
              >
                <SummaryView nav={nav} />
              </motion.div>
            )}
            {mode === "narrative" && (
              <motion.div
                key="narrative"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="absolute inset-0 flex flex-col"
              >
                <NarrativeView nav={nav} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </Shell>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [prevScreen, setPrevScreen] = useState<Screen>("splash");

  const nav = (s: Screen) => {
    setPrevScreen(screen);
    setScreen(s);
  };

  const ORDER: Screen[] = ["splash", "login", "ob1", "ob2", "ob3", "courses", "unit"];
  const dir = ORDER.indexOf(screen) >= ORDER.indexOf(prevScreen) ? 1 : -1;

  const views: Record<Screen, React.ReactNode> = {
    splash: <Splash nav={nav} />,
    login: <Login nav={nav} />,
    ob1: <Ob1 nav={nav} />,
    ob2: <Ob2 nav={nav} />,
    ob3: <Ob3 nav={nav} />,
    courses: <Courses nav={nav} />,
    unit: <Unit nav={nav} />,
  };

  return (
    <div className="size-full" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      <AnimatePresence mode="wait" custom={dir}>
        <Slide key={screen} dir={dir}>
          {views[screen]}
        </Slide>
      </AnimatePresence>
    </div>
  );
}
